package com.example.tp_candidats

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
