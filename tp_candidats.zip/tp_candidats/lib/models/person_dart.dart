class Person {
  String? name;
  String? surname;
  String? biographie;
  String? urlprofil;


  Person({this.name, this.surname, this.biographie, this.urlprofil});

  @override
  String toString() {
    return 'Person{name: $name, surname: $surname, biogaphie: $biographie, url: $urlprofil}';
  }
}
