import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/widgets.dart';
import '/models/person_dart.dart';
import '/pages/candidats_form_page.dart';
import '/pages/candidats_page.dart';

class CandidatsListPage extends StatefulWidget {
  const CandidatsListPage({super.key});

  @override
  State<CandidatsListPage> createState() => _CandidatsListPageState();
}

class _CandidatsListPageState extends State<CandidatsListPage> {
  String name = "";
  bool liked = false;
  List<Person> persons = [];
  List<Person> candidats = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Candidats aux élections"),
       // backgroundColor:Color(0524),
        actions: [
          IconButton(
              onPressed: () async {
                Person person = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CandidatsPage(
                        candidats:candidats,
                      ),
                    ));
                print(person.name);
                candidats.remove(person);
                setState(() {});
              },
              icon: Icon(Icons.how_to_vote_outlined))
        ],
      ),
      body: ListView(
        children: persons
            .map((person) => ListTile(
                  title: Text("${person.name} ${person.surname}"),
                 // subtitle: Text("B"),
                  leading: Card(),
                  trailing: const Icon(
                    Icons.face,
                    //color: checkIfExists(person) ? Colors.brown : Colors.black,
                  ),
                  onTap: () {
                    addCandidats(person);
                    setState(() {});
                  },
                ))
            .toList(),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          Person person = await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CandidatsFormPage()
              ));

          setState(() => persons.add(person));
        },
        child: Icon(Icons.mark_email_read_sharp),
      ),
    );
  }

  bool checkIfExists(Person person) {
    return candidats.contains(person);
  }

  void addCandidats(Person person) {
    if (!checkIfExists(person)) {
      candidats.add(person);
    } else {
      candidats.remove(person);
    }
  }
}
