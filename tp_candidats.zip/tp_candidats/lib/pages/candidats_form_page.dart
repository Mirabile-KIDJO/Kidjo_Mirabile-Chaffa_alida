import 'package:flutter/material.dart';
import '/common/I_button.dart';
import '/common/i_input.dart';
import '/models/person_dart.dart';

class CandidatsFormPage extends StatefulWidget {
  const CandidatsFormPage({super.key});

  @override
  State<CandidatsFormPage> createState() => _CandidatsFormPageState();
}

class _CandidatsFormPageState extends State<CandidatsFormPage> {
  final _formKey = GlobalKey<FormState>();
  final Person person= Person();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(""),
      ),
      body: Container(
        padding: EdgeInsets.all(10),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              IIinput(
                name: 'Nom',

                validator: (value) {
                  if (value!.isEmpty) {
                    return " Champ obligatoire";
                  }
                },
                onSaved: (value) {

                 // print("Valeur à sauvegarder $value");
                  person.name=value;

                },

                prefixIcon: Icon(Icons.person),
                suffixIcon: Icon(Icons.person),
              ),
             SizedBox(height: 10,),
              IIinput(
                name: 'Prenom',

                validator: (value) {
                  if (value!.isEmpty) {
                    return " Champ obligatoire";
                  }
                },
                onSaved: (value) {

                  // print("Valeur à sauvegarder $value");
                  person.surname=value;

                },

                prefixIcon: Icon(Icons.person),
                suffixIcon: Icon(Icons.person),
              ),
              SizedBox(height: 10,),
              IIinput(
                name: 'Biographie',

                validator: (value) {
                  if (value!.isEmpty) {
                    return " Champ obligatoire";
                  }
                },
                onSaved: (value) {

                  // print("Valeur à sauvegarder $value");
                  person.biographie=value;

                },

                prefixIcon: Icon(Icons.person),
                suffixIcon: Icon(Icons.person),
              ),
              SizedBox(height: 10,),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: IButton(
          onPressed: () {
          if(  _formKey.currentState!.validate()){
            _formKey.currentState!.save();
           Navigator.pop(context, person);
          }
          },
          text: 'Se faire enregistrer',
        ),
      ),
    );
  }
}
