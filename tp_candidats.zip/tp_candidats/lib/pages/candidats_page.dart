import 'package:flutter/material.dart';

import '../models/person_dart.dart';

class CandidatsPage extends StatelessWidget {
  final List<Person> candidats;

  CandidatsPage({super.key, required this.candidats});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Les candidats"),
        foregroundColor: Colors.brown,
      ),

      body: Row(
        children: candidats.map((person) => ListTile(
          title: Text("${person.name} ${person.surname}"),

          leading: Card( child: Image.asset('assets/images/'),),
          onTap: () => Navigator.pop(context, person),

      )).toList(),
    )
    );
  }
}
